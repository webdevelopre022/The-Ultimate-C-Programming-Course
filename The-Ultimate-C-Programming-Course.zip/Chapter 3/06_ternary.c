#include <stdio.h>

int main(){
    // condition ? expression-if-true : expression-if-false
    int a = 345;
    int b= 345452;
    a>b?printf("a is greater"):printf("b is greater");
}