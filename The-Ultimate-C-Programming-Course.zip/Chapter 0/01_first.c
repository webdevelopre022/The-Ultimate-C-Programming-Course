#include<stdio.h>
//5 star coder
int main(){
    printf("Hello World"); 
    return 0;
}