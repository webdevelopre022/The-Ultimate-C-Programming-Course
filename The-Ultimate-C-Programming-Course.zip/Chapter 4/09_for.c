#include <stdio.h>

int main(){
    int n = 6;
    for(int i =0;i<n;i++){
        printf("The value of i is %d\n");
    }
    return 0;
}