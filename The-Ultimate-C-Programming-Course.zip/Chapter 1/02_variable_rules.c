#include<stdio.h>

int main(){
    int rahul;
    int Rahul; 
    int Rahul_good;
    return 0;
}